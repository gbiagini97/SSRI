char *buildRequest(char *host, int port);
void execute (int sockfd, char *requestLine);