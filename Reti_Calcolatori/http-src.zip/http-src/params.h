
char *getHost();
int getPort();
char *getPath();
char *getMethod();
char *getHeaders(char *message);
char *getBody();
char *getEntityHeaders(char *body);